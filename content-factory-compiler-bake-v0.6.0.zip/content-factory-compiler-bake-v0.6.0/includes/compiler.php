<?php
if (!defined('ABSPATH')) { exit; }

function cfcc_compile_blueprint($data) {
  $dry = !empty($_POST['cfcc_dry_run']);

  if (empty($data['pages']) || !is_array($data['pages'])) {
    return array('error' => 'Blueprint muss ein Array "pages" enthalten.');
  }

  $created = 0;
  $updated = 0;

  // 1) Create/update all posts first so we can reference IDs
  $index = array(); // id => array(post_id, slug, url)

  foreach ($data['pages'] as $page) {
    if (empty($page['id']) || empty($page['slug']) || empty($page['title'])) {
      return array('error' => 'Seite hat fehlende Pflichtfelder: id, slug, title.');
    }

    $post_type = !empty($page['post_type']) ? $page['post_type'] : 'page';
    $status = !empty($page['status']) ? $page['status'] : 'publish';

    $existing = get_page_by_path($page['slug'], OBJECT, $post_type);

    $postarr = array(
      'post_type' => $post_type,
      'post_status' => $status,
      'post_title' => $page['title'],
      'post_name' => $page['slug'],
    );

    // Parent assignment (if provided as blueprint id)
    if (!empty($page['parent_id']) && !empty($index[$page['parent_id']]['post_id'])) {
      $postarr['post_parent'] = intval($index[$page['parent_id']]['post_id']);
    }

    if ($existing && !is_wp_error($existing)) {
      $postarr['ID'] = $existing->ID;
      if (!$dry) {
        wp_update_post($postarr);
      }
      $post_id = $existing->ID;
      $updated++;
    } else {
      if ($dry) {
        // Fake ID for dry-run
        $post_id = 0;
      } else {
        $post_id = wp_insert_post($postarr);
        if (is_wp_error($post_id)) {
          return array('error' => 'Konnte Seite nicht erstellen: ' . $page['slug'] . ' – ' . $post_id->get_error_message());
        }
      }
      $created++;
    }

    $url = !empty($page['url']) ? $page['url'] : home_url('/' . trim($page['slug'], '/') . '/');
    $index[$page['id']] = array('post_id' => $post_id, 'slug' => $page['slug'], 'url' => $url);
  }

  // 2) Second pass: bake content + meta + schema
  foreach ($data['pages'] as $page) {
    $pid = isset($index[$page['id']]['post_id']) ? intval($index[$page['id']]['post_id']) : 0;
    if ($dry) {
      // nothing
    } else {
      // Ensure parent now that all IDs exist
      if (!empty($page['parent_id']) && !empty($index[$page['parent_id']]['post_id'])) {
        wp_update_post(array('ID' => $pid, 'post_parent' => intval($index[$page['parent_id']]['post_id'])));
      }
    }

    // Determine content source: either blocks (preferred) or legacy 'content'
    $content = '';

    // Blocks structure (recommended): blocks[] where each block has type, props
    if (!empty($page['blocks']) && is_array($page['blocks'])) {
      foreach ($page['blocks'] as $block) {
        if (empty($block['type'])) continue;
        if ($block['type'] === 'tw_lp_embed_v1') {
          $props = !empty($block['props']) ? $block['props'] : array();
          $emit_mode = !empty($props['emit_mode']) ? $props['emit_mode'] : 'bake';
          // Force bake
          $props['emit_mode'] = 'bake';
          $content .= cfcc_bake_from_props($props, $page, $index);
        } elseif ($block['type'] === 'raw_flatsome') {
          $content .= !empty($block['html']) ? $block['html'] : '';
        }
      }
    } elseif (!empty($page['content'])) {
      $content = $page['content'];
    }

    if (!$content) {
      // Minimal fallback
      $content = '[section label="Money" bg_color="rgb(247, 246, 242)" padding="0px" class="lp-kueche lp-money"][row][col span="12"][ux_text]<h1>' . esc_html($page['title']) . '</h1>[/ux_text][/col][/row][/section]';
    }

    if (!$dry && $pid) {
      wp_update_post(array('ID' => $pid, 'post_content' => $content));
    }

    // RankMath meta
    if (!empty($page['seo']) && is_array($page['seo']) && !$dry && $pid) {
      cfcc_rankmath_apply($pid, $page['seo']);
    }

    // Store blueprint id marker
    if (!$dry && $pid) {
      update_post_meta($pid, '_cfcc_blueprint_id', sanitize_text_field($page['id']));
      update_post_meta($pid, '_cfcc_compiled_version', CFCC_VERSION);
    }
  }

  return array('created' => $created, 'updated' => $updated, 'notes' => 'Baked content + RankMath meta geschrieben.');
}
