<?php
if (!defined('ABSPATH')) { exit; }

function cfcc_bake_from_props($props, $page, $index) {
  $data = array();
  if (!empty($props['data']) && is_array($props['data'])) {
    $data = $props['data'];
  }

  // Merge some top-level fields
  if (empty($data['id']) && !empty($page['id'])) $data['id'] = $page['id'];

  $page_type = !empty($data['page_type']) ? $data['page_type'] : (!empty($page['page_type']) ? $page['page_type'] : 'money');
  if (!empty($page['template']) && $page['template'] === 'ratgeber') $page_type = 'ratgeber';

  if ($page_type === 'ratgeber') {
    return cfcc_bake_ratgeber($data, $page, $index);
  }

  // Default: money / geo money
  return cfcc_bake_money($data, $page, $index);
}

function cfcc_section_open($label, $class) {
  return '[section label="' . esc_attr($label) . '" bg_color="rgb(247, 246, 242)" padding="0px" class="' . esc_attr($class) . '"]';
}
function cfcc_section_close() { return '[/section]'; }

function cfcc_h($tag, $text) {
  return '[ux_text]<' . $tag . '>' . esc_html($text) . '</' . $tag . '>[/ux_text]';
}

function cfcc_ul($items) {
  $html = '<ul class="ih-bullets">';
  foreach ($items as $it) {
    $html .= '<li>' . $it . '</li>';
  }
  $html .= '</ul>';
  return '[ux_text]' . $html . '[/ux_text]';
}

function cfcc_schema_jsonld_block($schema_jsonld) {
  if (!$schema_jsonld) return '';
  // Ensure it's a string
  if (is_array($schema_jsonld) || is_object($schema_jsonld)) {
    $schema_jsonld = wp_json_encode($schema_jsonld, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
  }
  return '[ux_html]<script type="application/ld+json">' . $schema_jsonld . '</script>[/ux_html]';
}

function cfcc_bake_money($data, $page, $index) {
  $classes = 'lp-kueche lp-money';
  if (!empty($page['classes'])) $classes = $page['classes'];

  $out = cfcc_section_open('Money', $classes);
  $out .= '[row][col span="12"]';

  // HERO
  $hero = !empty($data['hero']) ? $data['hero'] : array();
  $h1 = !empty($hero['h1']) ? $hero['h1'] : $page['title'];
  $out .= '[ux_text]<h1>' . esc_html($h1) . '</h1>[/ux_text]';
  if (!empty($hero['lead_html'])) {
    $out .= '[ux_text]' . $hero['lead_html'] . '[/ux_text]';
  } elseif (!empty($hero['lead'])) {
    $out .= '[ux_text]<p>' . esc_html($hero['lead']) . '</p>[/ux_text]';
  }

  if (!empty($hero['badges']) && is_array($hero['badges'])) {
    $lis = array();
    foreach ($hero['badges'] as $b) { $lis[] = esc_html($b); }
    $out .= cfcc_ul($lis);
  } elseif (!empty($hero['bullets']) && is_array($hero['bullets'])) {
    $lis = array();
    foreach ($hero['bullets'] as $b) { $lis[] = esc_html($b); }
    $out .= cfcc_ul($lis);
  }

  // Optional Gallery placeholder: users handle via CSS/snippet
  if (!empty($data['gallery']['folder'])) {
    $folder = sanitize_title($data['gallery']['folder']);
    $limit = !empty($data['gallery']['limit']) ? intval($data['gallery']['limit']) : 6;
    $out .= '[ux_html]<div class="spiegel-gallery" data-folder="' . esc_attr($folder) . '" data-limit="' . esc_attr($limit) . '"></div>[/ux_html]';
  }

  // MATERIAL / CONTENT
  if (!empty($data['material']['title'])) {
    $out .= '[ux_text]<h2>' . esc_html($data['material']['title']) . '</h2>[/ux_text]';
    if (!empty($data['material']['paragraphs_html']) && is_array($data['material']['paragraphs_html'])) {
      foreach ($data['material']['paragraphs_html'] as $p) {
        $out .= '[ux_text]<p>' . $p . '</p>[/ux_text]';
      }
    }
  }

  // STEPS
  if (!empty($data['steps']['title'])) {
    $out .= '[ux_text]<h2>' . esc_html($data['steps']['title']) . '</h2>[/ux_text]';
    if (!empty($data['steps']['items']) && is_array($data['steps']['items'])) {
      $out .= '[accordion auto_open="true"]';
      foreach ($data['steps']['items'] as $it) {
        $t = (!empty($it['number']) ? $it['number'] . ') ' : '') . (!empty($it['title']) ? $it['title'] : '');
        $txt = !empty($it['text']) ? $it['text'] : '';
        $out .= '[accordion-item title="' . esc_attr($t) . '"][ux_text]<p>' . esc_html($txt) . '</p>[/ux_text][/accordion-item]';
      }
      $out .= '[/accordion]';
    }
    if (!empty($data['steps']['after_paragraphs']) && is_array($data['steps']['after_paragraphs'])) {
      foreach ($data['steps']['after_paragraphs'] as $p) {
        $out .= '[ux_text]<p>' . esc_html($p) . '</p>[/ux_text]';
      }
    }
  }

  // INFO BOXES (already HTML)
  if (!empty($data['info_boxes']) && is_array($data['info_boxes'])) {
    foreach ($data['info_boxes'] as $box) {
      $headline = !empty($box['headline']) ? $box['headline'] : '';
      $text_html = !empty($box['text_html']) ? $box['text_html'] : '';
      if ($headline) {
        $out .= '[ux_text]<h3>' . esc_html($headline) . '</h3>[/ux_text]';
      }
      if ($text_html) {
        $out .= '[ux_text]' . $text_html . '[/ux_text]';
      }
    }
  }

  // TRUST
  if (!empty($data['trust']['title'])) {
    $out .= '[ux_text]<h2>' . esc_html($data['trust']['title']) . '</h2>[/ux_text]';
    if (!empty($data['trust']['items']) && is_array($data['trust']['items'])) {
      $out .= '[row]';
      foreach ($data['trust']['items'] as $it) {
        $out .= '[col span="6" span__sm="12"]';
        $out .= '[ux_text]<h3>' . esc_html($it['title']) . '</h3><p>' . esc_html($it['text']) . '</p>[/ux_text]';
        $out .= '[/col]';
      }
      $out .= '[/row]';
    }
  }

  // PRAXIS
  if (!empty($data['praxis']['title'])) {
    $out .= '[ux_text]<h2>' . esc_html($data['praxis']['title']) . '</h2>[/ux_text]';
    if (!empty($data['praxis']['items']) && is_array($data['praxis']['items'])) {
      foreach ($data['praxis']['items'] as $it) {
        $out .= '[ux_text]<h3>' . esc_html($it['heading']) . '</h3><p>' . esc_html($it['text']) . '</p>[/ux_text]';
      }
    }
  }

  // INQUIRY CTA / FORM
  if (!empty($data['inquiry']['title'])) {
    $out .= '[ux_text]<h2 id="angebot">' . esc_html($data['inquiry']['title']) . '</h2>[/ux_text]';
    if (!empty($data['inquiry']['text'])) {
      $out .= '[ux_text]<p>' . esc_html($data['inquiry']['text']) . '</p>[/ux_text]';
    }
    // Keep global CTA as snippet to avoid recompiles
    $out .= '[tw_lp_cta]';
  }

  // FAQ
  if (!empty($data['faq']['title']) || !empty($data['faq']['headline'])) {
    $ftitle = !empty($data['faq']['title']) ? $data['faq']['title'] : $data['faq']['headline'];
    $out .= '[ux_text]<h2>' . esc_html($ftitle) . '</h2>[/ux_text]';
    if (!empty($data['faq']['subtitle'])) {
      $out .= '[ux_text]<p>' . esc_html($data['faq']['subtitle']) . '</p>[/ux_text]';
    }
    if (!empty($data['faq']['items']) && is_array($data['faq']['items'])) {
      $out .= '[accordion]';
      foreach ($data['faq']['items'] as $qa) {
        $q = !empty($qa['question']) ? $qa['question'] : (!empty($qa['q']) ? $qa['q'] : '');
        $a = !empty($qa['answer_html']) ? $qa['answer_html'] : (!empty($qa['a']) ? '<p>' . esc_html($qa['a']) . '</p>' : '');
        $out .= '[accordion-item title="' . esc_attr($q) . '"][ux_text]' . $a . '[/ux_text][/accordion-item]';
      }
      $out .= '[/accordion]';
    }
  }

  // Schema JSON-LD (only)
  $schema_jsonld = '';
  if (!empty($data['schema_jsonld'])) {
    $schema_jsonld = $data['schema_jsonld'];
  } elseif (!empty($page['schema_jsonld'])) {
    $schema_jsonld = $page['schema_jsonld'];
  } elseif (!empty($data['schema']) && is_array($data['schema'])) {
    // If schema already prepared as array, include it
    $schema_jsonld = $data['schema'];
  }
  $out .= cfcc_schema_jsonld_block($schema_jsonld);

  $out .= '[/col][/row]';
  $out .= cfcc_section_close();

  return $out;
}

function cfcc_bake_ratgeber($data, $page, $index) {
  $classes = 'lp-kueche lp-ratgeber';
  $out = '[section label="Ratgeber" padding="0px" class="' . esc_attr($classes) . '"]';
  $out .= '[row][col span="12"]';

  $h1 = !empty($data['h1']) ? $data['h1'] : $page['title'];
  $out .= '[ux_text]<h1>' . esc_html($h1) . '</h1>[/ux_text]';

  if (!empty($data['intro_html'])) {
    $out .= '[ux_text]' . $data['intro_html'] . '[/ux_text]';
  } elseif (!empty($data['intro'])) {
    $out .= '[ux_text]<p>' . esc_html($data['intro']) . '</p>[/ux_text]';
  }

  // Sections
  if (!empty($data['sections']) && is_array($data['sections'])) {
    foreach ($data['sections'] as $sec) {
      if (!empty($sec['headline'])) {
        $out .= '[ux_text]<h2>' . esc_html($sec['headline']) . '</h2>[/ux_text]';
      }
      if (!empty($sec['paragraphs']) && is_array($sec['paragraphs'])) {
        foreach ($sec['paragraphs'] as $p) {
          $out .= '[ux_text]<p>' . esc_html($p) . '</p>[/ux_text]';
        }
      }
      if (!empty($sec['paragraphs_html']) && is_array($sec['paragraphs_html'])) {
        foreach ($sec['paragraphs_html'] as $p) {
          $out .= '[ux_text]<p>' . $p . '</p>[/ux_text]';
        }
      }
      if (!empty($sec['bullets']) && is_array($sec['bullets'])) {
        $lis = array();
        foreach ($sec['bullets'] as $b) { $lis[] = esc_html($b); }
        $out .= cfcc_ul($lis);
      }
    }
  }

  // Backlinks to money/geo
  if (!empty($data['backlinks_html'])) {
    $out .= '[ux_text]' . $data['backlinks_html'] . '[/ux_text]';
  }

  // FAQ
  if (!empty($data['faq']) && is_array($data['faq']) && !empty($data['faq']['items'])) {
    $out .= '[ux_text]<h2>' . esc_html(!empty($data['faq']['headline']) ? $data['faq']['headline'] : 'FAQ') . '</h2>[/ux_text]';
    $out .= '[accordion]';
    foreach ($data['faq']['items'] as $qa) {
      $q = !empty($qa['question']) ? $qa['question'] : (!empty($qa['q']) ? $qa['q'] : '');
      $a = !empty($qa['answer_html']) ? $qa['answer_html'] : (!empty($qa['a']) ? '<p>' . esc_html($qa['a']) . '</p>' : '');
      $out .= '[accordion-item title="' . esc_attr($q) . '"][ux_text]' . $a . '[/ux_text][/accordion-item]';
    }
    $out .= '[/accordion]';
  }

  // Schema JSON-LD only
  $schema_jsonld = '';
  if (!empty($data['schema_jsonld'])) $schema_jsonld = $data['schema_jsonld'];
  $out .= cfcc_schema_jsonld_block($schema_jsonld);

  $out .= '[/col][/row][/section]';
  return $out;
}
