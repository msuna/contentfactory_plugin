<?php
if (!defined('ABSPATH')) { exit; }

function cfcc_render_admin_page() {
  if (!current_user_can('manage_options')) {
    wp_die('Insufficient permissions.');
  }

  $notice = '';
  $error = '';

  if (isset($_POST['cfcc_upload_nonce']) && wp_verify_nonce($_POST['cfcc_upload_nonce'], 'cfcc_upload')) {
    if (!empty($_FILES['cfcc_blueprint_file']['tmp_name'])) {
      $json = file_get_contents($_FILES['cfcc_blueprint_file']['tmp_name']);
      $data = json_decode($json, true);
      if (!is_array($data)) {
        $error = 'Blueprint JSON ist ungültig. Bitte prüfen (JSON decode failed).';
      } else {
        $result = cfcc_compile_blueprint($data);
        if (!empty($result['error'])) {
          $error = $result['error'];
        } else {
          $notice = 'OK: ' . intval($result['created']) . ' erstellt, ' . intval($result['updated']) . ' aktualisiert. ' . (!empty($result['notes']) ? esc_html($result['notes']) : '');
        }
      }
    } else {
      $error = 'Keine Datei gewählt.';
    }
  }

  echo '<div class="wrap">';
  echo '<h1>Content Factory – Compiler (Bake)</h1>';
  echo '<p><strong>PHP (Web):</strong> ' . esc_html(PHP_VERSION) . ' &nbsp; <strong>CFCC:</strong> ' . esc_html(CFCC_VERSION) . '</p>';

  if ($notice) {
    echo '<div class="notice notice-success"><p>' . $notice . '</p></div>';
  }
  if ($error) {
    echo '<div class="notice notice-error"><p>' . esc_html($error) . '</p></div>';
  }

  echo '<form method="post" enctype="multipart/form-data">';
  wp_nonce_field('cfcc_upload', 'cfcc_upload_nonce');
  echo '<table class="form-table"><tbody>';
  echo '<tr><th scope="row">Batch Blueprint (JSON)</th><td><input type="file" name="cfcc_blueprint_file" accept="application/json" required></td></tr>';
  echo '<tr><th scope="row">Modus</th><td><label><input type="checkbox" name="cfcc_dry_run" value="1"> Dry-Run (nichts schreiben)</label></td></tr>';
  echo '</tbody></table>';
  submit_button('Kompilieren (Bake)');
  echo '</form>';

  echo '<hr/>';
  echo '<p><strong>Hinweis:</strong> Dieses Plugin schreibt <em>baked</em> Flatsome UX Shortcodes direkt in <code>post_content</code>. JSON wird nur noch als Schema JSON-LD in den Content geschrieben.</p>';
  echo '</div>';
}
