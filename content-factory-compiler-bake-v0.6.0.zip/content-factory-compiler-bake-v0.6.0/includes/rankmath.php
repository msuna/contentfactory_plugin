<?php
if (!defined('ABSPATH')) { exit; }

function cfcc_rankmath_apply($post_id, $seo) {
  // Rank Math meta keys
  if (isset($seo['title'])) {
    update_post_meta($post_id, 'rank_math_title', wp_kses_post($seo['title']));
  }
  if (isset($seo['description'])) {
    update_post_meta($post_id, 'rank_math_description', wp_kses_post($seo['description']));
  }
  if (isset($seo['focus_keyword'])) {
    update_post_meta($post_id, 'rank_math_focus_keyword', sanitize_text_field($seo['focus_keyword']));
  }
  if (!empty($seo['canonical'])) {
    update_post_meta($post_id, 'rank_math_canonical_url', esc_url_raw($seo['canonical']));
  }
  if (!empty($seo['robots']) && is_array($seo['robots'])) {
    // RankMath stores robots as array in rank_math_robots
    update_post_meta($post_id, 'rank_math_robots', array_values($seo['robots']));
  }

  // Social
  if (!empty($seo['og_title'])) update_post_meta($post_id, 'rank_math_facebook_title', wp_kses_post($seo['og_title']));
  if (!empty($seo['og_description'])) update_post_meta($post_id, 'rank_math_facebook_description', wp_kses_post($seo['og_description']));
  if (!empty($seo['twitter_title'])) update_post_meta($post_id, 'rank_math_twitter_title', wp_kses_post($seo['twitter_title']));
  if (!empty($seo['twitter_description'])) update_post_meta($post_id, 'rank_math_twitter_description', wp_kses_post($seo['twitter_description']));
}
