<?php
/*
Plugin Name: Content Factory Compiler (Flatsome) – Bake
Description: Upload batch blueprint JSON and compile Money + Ratgeber + GEO cluster pages into real baked Flatsome UX shortcodes + RankMath meta. JSON is only used for Schema JSON-LD.
Version: 0.6.0
Author: Content Factory
*/

if (!defined('ABSPATH')) { exit; }

define('CFCC_VERSION', '0.6.0');
define('CFCC_PLUGIN_DIR', plugin_dir_path(__FILE__));


require_once CFCC_PLUGIN_DIR . 'includes/admin.php';
require_once CFCC_PLUGIN_DIR . 'includes/compiler.php';
require_once CFCC_PLUGIN_DIR . 'includes/baker_flatsome.php';
require_once CFCC_PLUGIN_DIR . 'includes/rankmath.php';

add_action('admin_menu', function () {
  add_submenu_page(
    'tools.php',
    'Content Factory',
    'Content Factory',
    'manage_options',
    'content-factory',
    'cfcc_render_admin_page'
  );
});

// Simple health endpoint for troubleshooting
add_action('admin_init', function () {
  if (!current_user_can('manage_options')) return;
  if (!isset($_GET['cfcc_health'])) return;
  wp_die('CFCC OK – PHP '.PHP_VERSION.' – WP '.get_bloginfo('version').' – CFCC '.CFCC_VERSION);
});
